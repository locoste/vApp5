exports.user= 'Test_3';
exports.password= 'aqwzsxedc';
exports.server= 'localhost';
exports.database= 'Lxp';