exports.hostAPR= 'localhost';
exports.userAPR= 'Test_3';
exports.passwordAPR= 'aqwzsxedc';
exports.databaseSchemaAPR= 'Lxp';
exports.hostTARDY= 'localhost';
exports.userTARDY= 'root';
exports.passwordTARDY= 'Lamoule07130';
exports.databaseSchemaTARDY= 'tardy_scheduler';