exports.dbType= 'mysql';
exports.host= 'localhost';
exports.port= '3306';
exports.user= 'root';
exports.password= 'Lamoule07130';
exports.databaseSchema= 'vapp5';